#ifndef ARRAY_HELPER
#define ARRAY_HELPER

int printAvgMaxMin(int* arr, int size);

#endif
