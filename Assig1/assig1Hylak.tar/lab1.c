/* Example C program for CS2303 Lab 1 */

#include <stdio.h> 
 
int main() 
{
	int i; // Loop counter 
  	printf("Hello, World!\n"); // Print a cheery greeting! 
 
  	/* This loop prints the numbers from 1 to 20, one per line. */  
	for (i = 1; i <= 20; i++) {     
		printf("%d\n", i); // Print the next number  
	 }
 
	printf("Goodbye!\n");
}  
